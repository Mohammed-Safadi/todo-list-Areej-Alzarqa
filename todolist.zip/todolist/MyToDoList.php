<?php
$db = mysqli_connect('localhost', 'root', '', 'todolist');
if(!$db){
    die('cannot connect to database!!');
}

if($_POST){
    $sql = 'INSERT INTO php_list (lis) VALUE (?)';
    $stmt = $db->prepare($sql);
    $stmt->bind_param('s', $_POST['task']);
   if ($stmt->execute()){
       header('location:MyToDoList.php');
   }
}

if(isset($_GET['done']) && $_GET['done'] != 1){
    $sql = 'UPDATE  php_list
      SET done = 1
      
     ';
    $stmt = $db->prepare($sql);
    if ($stmt->execute()){
        header('location:MyToDoList.php');
    }

}



if(isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['lis'])){
    $sql = 'DELETE FROM php_list WHERE lis = ?';
    $stmt = $db->prepare($sql);
    $stmt->bind_param('s', $_GET['lis']);
    $stmt->execute();
}

?>


<!DOCTYPE html>
    <html>
        <head>
            <title> MyTodo-List </title>
            <meta charset="utf-8">
            <meta name="viewport" content="width=device-width, initial-scale=1">
            <link rel="stylesheet" type="text/css" href="assets/css/style.css">
        </head>

        <body>
            <div class="container">
                <div class="list">
                   <h1> My To-do's List </h1>
                    <form method="POST" action="MyToDoList.php">
                    <input type="text"  placeholder="New Task..." class="" id="name" name="task" >
                    <button class="add" id="addto" type="submit"> Add to List</button>
                    </form>
                </div>

                <?php
                    $sql = 'SELECT * from php_list';
                    $result = $db->query($sql);
                    while (($row = $result->fetch_assoc())):
                    ?>
                <ul id="myUL">
                    <li id="myli">
                        <span>  <?= $row['lis'] ?> <?= $row['done'] ? '  /done' : '' ?></span>
                        <?php if(!$row['done']): ?>
                        <a href="MyToDoList.php?done=<?= $row['done'] ?> "  class="donebtn" > | &nbsp Mark as Done </a>
                        
                        <?php endif; ?>
                        <a href="MyToDoList.php?action=delete&lis=<?= $row['lis'] ?>"  class="deletebtn" id="dele" > &nbsp Delete</a>                          
                    </li>
               
                 <?php endwhile ?>



<!--
            <script>
                var button = document.getElementById('dele');
                var deletebtn = document.getElementsByClassName("deletebtn");
            
                button.addEventListener("click", function(){
                    for ( var i = 0; i < deletebtn.length; i++) {
                    var dele = this.parentElement;
                    dele.style.display = "none";
                    }
                })
 
                var input = document.getElementById('name');
                var span = document.getElementById('addto');
                var li = document.getElementsByTagName('li');
                var li = document.getElementById('myli');

                span.addEventListener("click", function(){
                    var li = document.createElement("li");
                    var inputValue = document.getElementById("name").value;
                    var t = document.createTextNode(inputValue);
                    li.appendChild(t);
                
                    document.getElementById("myUL").appendChild(li);
                    document.getElementById("name").value = "";

                    var span = document.createElement("SPAN");
                    var x =  document.getElementsByClassName("donebtn").value;
                    var txt = document.createTextNode("x");
                    li.appendChild(x);
                    document.getElementById("myUL").appendChild(txt);
                    document.getElementById("donebtn").value = "";
                    span.appendChild(txt);
                    li.appendChild(span);

            
                })
            </script>

            -->

        </body>  
    </html>      